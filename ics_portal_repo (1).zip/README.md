ICS - Integric Check Solutions Investigation Portal
==================================================

This repository contains a single Dockerized web app (FastAPI + React) that serves the frontend from FastAPI.
It's configured so you can deploy the single service to Render.com (or any container service) using the Dockerfile at backend/Dockerfile.

Quick Local Docker test (requires Docker):
1. From repository root run:
   docker build -f backend/Dockerfile -t ics_portal:latest .
2. Run:
   docker run -p 8000:8000 ics_portal:latest
3. Open http://localhost:8000 in your browser.

Quick Deploy on Render (recommended for non-technical users):
1. Create a free account at https://render.com
2. Create a new Web Service -> Connect a GitHub repo (you can upload this repo as a new GitHub repo)
3. For "Environment" select Docker, and point Render to use the Dockerfile at /backend/Dockerfile
4. Set the PORT to 8000 (Render often sets this automatically)
5. Deploy — Render will build the image and run the container. After deploy you'll get a public URL.

Notes:
- The app uses SQLite by default for simplicity. For production and multiple users, switch to PostgreSQL and set DATABASE_URL accordingly.
- For PDF generation: wkhtmltopdf is optional; if not installed, the endpoint returns HTML instead.
- To create initial investigators, call POST /api/investigators/ with JSON {name, email, mobile}.
