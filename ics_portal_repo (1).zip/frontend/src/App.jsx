import React, {useEffect, useState} from 'react'
import axios from 'axios'
const API = import.meta.env.VITE_API_BASE || '/api'

export default function App(){
  const [cases, setCases] = useState([])
  useEffect(()=>{ load() },[])
  async function load(){ try{ const res = await axios.get(`${API}/cases/`); setCases(res.data) }catch(e){ console.error(e) } }
  return (<div style={{maxWidth:900, margin:'20px auto', fontFamily:'Arial'}}>
    <h1>ICS - Integric Check Solutions</h1>
    <a href="/create.html">New Investigation</a>
    <h3>Recent Cases</h3>
    <ul>{cases.map(c=><li key={c.id}>{c.report_no} — {c.applicant_name} — {c.status}</li>)}</ul>
  </div>)
}
