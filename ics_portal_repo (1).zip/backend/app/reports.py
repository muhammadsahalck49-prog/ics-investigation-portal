from jinja2 import Environment, FileSystemLoader, select_autoescape
import pdfkit
from pathlib import Path

env = Environment(loader=FileSystemLoader(searchpath=str(Path(__file__).resolve().parents[1] / 'templates')), autoescape=select_autoescape(['html','xml']))

def render_html(case_dict):
    tpl = env.get_template('case_report.html')
    return tpl.render(case=case_dict)

def html_to_pdf_bytes(html):
    try:
        return pdfkit.from_string(html, False)
    except Exception as e:
        print('pdfkit error:', e)
        return None
