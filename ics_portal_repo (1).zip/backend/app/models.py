from sqlalchemy import Column, Integer, String, Text, Date, DateTime, ForeignKey, Numeric
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class Investigator(Base):
    __tablename__ = 'investigators'
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String)
    mobile = Column(String)
    role = Column(String, default='investigator')

class Case(Base):
    __tablename__ = 'cases'
    id = Column(Integer, primary_key=True, index=True)
    report_no = Column(String, unique=True, index=True, nullable=False)
    report_date = Column(String, nullable=True)
    office_name = Column(String, nullable=True)
    accident_date = Column(String, nullable=True)
    accident_time = Column(String, nullable=True)
    accident_place = Column(String, nullable=True)
    insured_vehicle_no = Column(String, nullable=True)
    policy_number = Column(String, nullable=True)
    applicant_name = Column(String, nullable=True)
    findings = Column(Text, nullable=True)
    analysis = Column(Text, nullable=True)
    recommendations = Column(Text, nullable=True)
    status = Column(String, default='Draft')
    investigator_id = Column(Integer, ForeignKey('investigators.id'), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    investigator = relationship("Investigator")
