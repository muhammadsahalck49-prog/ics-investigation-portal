from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from . import database, models, schemas, crud, reports
import os, shutil
from fastapi.responses import StreamingResponse, HTMLResponse

app = FastAPI(title='ICS Investigation Portal')

# serve frontend static from /static (frontend build will be copied into ./frontend_build)
if os.path.isdir('frontend_build'):
    app.mount('/', StaticFiles(directory='frontend_build', html=True), name='frontend')

database.Base.metadata.create_all(bind=database.engine)

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

UPLOAD_DIR = os.getenv('UPLOAD_DIR','./uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post('/api/investigators/')
def create_investigator(inv: schemas.InvestigatorCreate, db: Session = Depends(get_db)):
    return crud.create_investigator(db, inv.name, inv.email, inv.mobile)

@app.post('/api/cases/')
def create_case(case: schemas.CaseCreate, db: Session = Depends(get_db)):
    data = case.dict()
    return crud.create_case(db, data)

@app.get('/api/cases/')
def list_cases(db: Session = Depends(get_db)):
    return crud.list_cases(db)

@app.get('/api/cases/{case_id}/report')
def get_case_report(case_id: int, db: Session = Depends(get_db)):
    case = crud.get_case(db, case_id)
    if not case:
        raise HTTPException(status_code=404, detail='Case not found')
    case_dict = {c.name: getattr(case, c.name) for c in case.__table__.columns}
    html = reports.render_html(case_dict)
    pdf_bytes = reports.html_to_pdf_bytes(html)
    if pdf_bytes:
        return StreamingResponse(iter([pdf_bytes]), media_type='application/pdf', headers={'Content-Disposition':f'attachment; filename=report_{case.report_no}.pdf'})
    else:
        return HTMLResponse(content=html)
