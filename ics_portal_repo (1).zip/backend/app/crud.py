from sqlalchemy.orm import Session
from . import models

def create_investigator(db: Session, name, email=None, mobile=None):
    inv = models.Investigator(name=name, email=email, mobile=mobile)
    db.add(inv); db.commit(); db.refresh(inv)
    return inv

def create_case(db: Session, case_data: dict):
    c = models.Case(**case_data)
    db.add(c); db.commit(); db.refresh(c)
    return c

def list_cases(db: Session, limit=100):
    return db.query(models.Case).order_by(models.Case.created_at.desc()).limit(limit).all()

def get_case(db: Session, case_id: int):
    return db.query(models.Case).filter(models.Case.id==case_id).first()
