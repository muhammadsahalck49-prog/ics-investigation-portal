from pydantic import BaseModel
from typing import Optional

class InvestigatorCreate(BaseModel):
    name: str
    email: Optional[str] = None
    mobile: Optional[str] = None

class CaseCreate(BaseModel):
    report_no: str
    report_date: Optional[str] = None
    office_name: Optional[str] = None
    accident_date: Optional[str] = None
    accident_time: Optional[str] = None
    accident_place: Optional[str] = None
    insured_vehicle_no: Optional[str] = None
    policy_number: Optional[str] = None
    applicant_name: Optional[str] = None
    findings: Optional[str] = None
    analysis: Optional[str] = None
    recommendations: Optional[str] = None
